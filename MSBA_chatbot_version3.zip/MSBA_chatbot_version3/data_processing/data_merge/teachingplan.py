import pandas as pd

import pdfplumber
import pandas as pd
import numpy as np

pdf = pdfplumber.open('MSBA-teaching-plan-2024-25_20241128.pdf')

df = pd.DataFrame()

for i in range(len(pdf.pages)):
    page = pdf.pages[i]
    table = page.extract_table()
    data = pd.DataFrame(table[1:], columns=table[0])
    df = pd.concat([df, data], ignore_index=True)

df.to_csv('teaching_plan.csv', index=False)
data = pd.read_excel('extracted_by_sections.xlsx')

df = pd.read_csv('teaching_plan.csv')

df['Tutorial Dates and Time & Tutorial Venue'] = df['Tutorial Group']
df['Tutorial Group'] = np.nan
df['Course Code & Title'] = df['Course Code & Title'].ffill()
df['Course Type*'] = df['Course Type*'].ffill()
df['Instructor'] = df['Instructor'].ffill()
df['Exam / Final project Date, Time and Venue'] = df['Exam / Final project Date, Time and Venue'].ffill()

# df['Tutorial\nGroup']= df['Tutorial\nGroup'].astype(str)

# df = df.rename(columns={'Tutorial\nGroup': 'Tutorial Group & Tutorial Dates and Time & Tutorial Venue'})
df = df.rename(columns={'Tutorial\nGroup': 'Tutorial Group'})
df = df.rename(columns={'Tutorial Dates and\nTime': 'Tutorial Dates and Time & Tutorial Venue'})
df = df.drop(columns=['Tutorial Venue'])
#
# # df.to_csv('teaching_plan_cleaned.csv', index=False)
#
df1 = pd.read_csv('teaching_plan_cleaned2.csv')
df2 = pd.read_csv('teaching_plan_cleaned.csv')
# df = pd.concat([df1, df2], ignore_index=True)
# df.to_csv('teaching_plan_cleaned_all.csv', index=False)
# #
# df['CourseCode & Subclass'] = df['Course Code & Title'].str.split('\n').str[0] + df['Class']
# df = df.rename(columns={'Class Venue*': 'Class Venue'})
# df = df.rename(columns={'Course Type*': 'Course Type'})
# df.to_csv('teaching_plan_cleaned.csv', index=False)
import pandas as pd
import sqlite3

data = pd.read_excel('extracted_by_sections.xlsx')

print(data.head())

data['CourseCode'] = data['FileName'].str.extract(r'_([A-Z]{4}\d{4})_')
data.loc[4, 'CourseCode'] = 'MSBA7012_MACC7022'
data.loc[5, 'CourseCode'] = 'MSBA7013'
data.loc[6, 'CourseCode'] = 'MSBA7013A'
data.loc[8, 'CourseCode'] = 'MSBA7016'
data.loc[11, 'CourseCode'] = 'MSBA7023'
data.loc[25, 'CourseCode'] = 'MSMK7026'

data['CourseName'] = data['FileName'].str.extract(r'_[A-Z]{4}\d{4}_(.*?)-\(')
data.loc[4, 'CourseName'] = data.CourseName[4].split('_')[1]
data.loc[5, 'CourseName'] = 'Forecasting-and-Predictive-Analytics'
data.loc[6, 'CourseName'] = data.CourseName[5]
data.loc[8, 'CourseName'] = 'Supply-Chain-and-Logistics-Management'
data.loc[11, 'CourseName']= 'Geospatial-and-Business-Analytics'

data.to_csv('extracted_by_section_m.csv', index=False, encoding='utf-8-sig')

# Read data from CSV file
csv_file = 'extracted_by_section_m.csv'
data = pd.read_csv(csv_file)

# Connect to SQLite database (or create it if it doesn't exist)
conn = sqlite3.connect('Course_reg.db')
cursor = conn.cursor()

# # Delete the 'teaching_plan' table
# cursor.execute("DROP TABLE IF EXISTS teaching_plan")
#
# # Commit the transaction and close the connection
# conn.commit()
# conn.close()
#
# print("The 'teaching_plan' table has been deleted from Course_reg.db")

# Create a table in the SQLite database
table_name1 = 'course_data'
data.to_sql(table_name1, conn, if_exists='replace', index=False)

# Commit the transaction and close the connection
conn.commit()
# # conn.close()
#
# print(f"Data from {csv_file} has been saved to the {table_name1} table in Course_reg.db")
#
csv_file2 = 'teaching_plan_cleaned_all.csv'
data2 = pd.read_csv(csv_file2)
# Create a table in the SQLite database
table_name2 = 'teaching_plan'
data2.to_sql(table_name2, conn, if_exists='replace', index=False)

# Commit the transaction and close the connection
conn.commit()
conn.close()

print(f"Data from {csv_file2} has been saved to the {table_name2} table in Course_reg.db")

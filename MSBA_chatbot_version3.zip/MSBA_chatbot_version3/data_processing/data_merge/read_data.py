import pandas as pd
import sqlite3

# Connect to the SQLite database
conn = sqlite3.connect('Course_reg.db')

# Read data from the 'course_data' table
course_data_df = pd.read_sql_query("SELECT * FROM course_data", conn)
print("Course Data:")
print(course_data_df.head())

# Read data from the 'teaching_plan' table
teaching_plan_df = pd.read_sql_query("SELECT * FROM teaching_plan", conn)
print("Teaching Plan:")
print(teaching_plan_df.head())

# Close the connection
conn.close()
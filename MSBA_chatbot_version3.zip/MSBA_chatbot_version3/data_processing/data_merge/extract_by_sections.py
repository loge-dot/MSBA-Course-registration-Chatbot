import pandas as pd
import os
import PyPDF2
import re

# Path to the PDF file
# pdf_path = 'outlines/Course_Outline_MSBA7003_Decision_Analytics_Dr_Wei_Zhang-(2024-25).pdf'

def read_pdf(file_path):
    with open(file_path, "rb") as file:
        reader = PyPDF2.PdfReader(file)
        content = []
        for page in reader.pages:
            content.append(page.extract_text())
        return content

def read_txt(file_path):
    with open(file_path, "r", encoding="utf-8") as file:
        content = file.readlines()
    return content
# pdf_content = read_pdf(pdf_path)

def find_titles(content):
    # titles = []
    all_content = '\n'.join(content)
    return re.findall(r'\n\s*([A-Z]+[A-Z\s+/&]+(?:\(.*?\))?)\s*\n', all_content)

# titles = find_titles(pdf_content)

def split_pdf_by_title(content, titles):
    all_content = '\n'.join(content)
    sections = re.split(r'\n\s*[A-Z]+[A-Z\s+/&]+(?:\(.*?\))?\s*\n', all_content)
    extracted_sections = {}
    for i, title in enumerate(titles):
        extracted_sections[title] = sections[i + 1].strip() if i + 1 < len(sections) else ''
    return extracted_sections

# sections = split_pdf_by_title(pdf_content, titles)

def clean_sections(sections):
    cleaned_sections = {k.rstrip().replace('\n',''): v for k, v in sections.items()}
    df = pd.DataFrame([cleaned_sections])
    df.insert(0, 'FileName', pdf_path)
    return df

# sections_df = clean_sections(sections)

pdf_directory = 'outlines'

pdf_files = [os.path.join(pdf_directory, f) for f in os.listdir(pdf_directory) if f.endswith('.txt')]

all_sections = pd.DataFrame()
for pdf_path in pdf_files:
    print(f'Processing {pdf_path}')
    pdf_content = read_txt(pdf_path)
    titles = find_titles(pdf_content)
    sections = split_pdf_by_title(pdf_content, titles)
    sections_df = clean_sections(sections)
    all_sections = pd.concat([all_sections, sections_df], ignore_index=True)

all_sections.to_csv('extracted_by_sections.csv', index=False, encoding='utf-8')
# data = pd.read_csv('extracted_information.csv')
#
# print(data.head())
#
# data.CourseCode = data['Filename'].str.extract(r'_([A-Z]{4}\d{4})_')
# data.CourseCode[4] = 'MSBA7012_MACC7022'
# data.CourseCode[5] = 'MSBA7013'
# data.CourseCode[6] = 'MSBA7013A'
# data.CourseCode[8] = 'MSBA7016'
# data.CourseCode[11] = 'MSBA7023'
# data.CourseCode[25] = 'MSMK7026'
#
# data.CourseName = data['Filename'].str.extract(r'_[A-Z]{4}\d{4}_(.*?)-\(')
# data.CourseName[4] = data.CourseName[4].split('_')[1]
# data.CourseName[5] = 'Forecasting-and-Predictive-Analytics'
# data.CourseName[6] = data.CourseName[5]
# data.CourseName[8] = 'Supply-Chain-and-Logistics-Management'
# data.CourseName[11] = 'Geospatial-and-Business-Analytics'
#
# directory = 'outlines'
#
# # Iterate over all files in the directory
# for filename in os.listdir(directory):
#     if filename.endswith('.txt'):
#         file_path = os.path.join(directory, filename)
#         with open(file_path, 'r') as file:
#             data = file.read()


